import { numberAdd2 } from './number'
import { login } from './user'

export {
    numberAdd2,
    login
}