export function numberAdd2(dispatch) {
    dispatch({ type: 'numberAdd2' })
}
