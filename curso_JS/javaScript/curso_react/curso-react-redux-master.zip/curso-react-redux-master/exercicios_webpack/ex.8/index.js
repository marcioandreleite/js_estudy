import 'react'

export default props => (
    null
)

console.log('Funcionou!')