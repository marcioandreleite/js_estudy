import './estilo.css'
import 'react'

export default props => (
    <h1>Olá</h1>
)

console.log('Funcionou!')