function info(text) {
    console.log(`INFO: ${text}`)
}

module.exports = { info }