import React from 'react'

export default props => {
    return (
        <h3>{props.numero}</h3>
    )
}