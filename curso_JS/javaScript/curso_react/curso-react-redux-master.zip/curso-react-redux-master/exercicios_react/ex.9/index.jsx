import React from 'react'
import ReactDOM from 'react-dom'

import SilvaFamily from './silvaFamily'

ReactDOM.render(
    <SilvaFamily />
, document.getElementById('app'))