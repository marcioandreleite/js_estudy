import React from 'react'

const About = props => (
    <div className="About">
        <h1>Sobre</h1>
        <h2>O nosso sistema foi criado...</h2>
    </div>
)

export default About