import React from 'react'

const Home = props => (
    <div className="Home">
        <h1>Início</h1>
        <h2>Bem vindo!</h2>
    </div>
)

export default Home